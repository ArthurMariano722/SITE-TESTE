-- CRIE.AI: banco do site (pedidos, agendamentos e mensagens)
-- Cole tudo no SQL Editor do Supabase e clique em Run. Pode rodar de novo sem problema.

create table if not exists public.site_inbox (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('pedido', 'agendamento', 'contato')),
  data jsonb not null check (pg_column_size(data) <= 16384),
  status text not null default 'novo' check (status in ('novo', 'andamento', 'concluido', 'cancelado')),
  created_at timestamptz not null default now()
);
create index if not exists site_inbox_time on public.site_inbox (created_at desc);

-- Quem pode ver e mudar as mensagens: só os e-mails da lista no fim deste script.
create table if not exists public.site_admins (
  user_id uuid primary key references auth.users (id) on delete cascade
);

alter table public.site_inbox enable row level security;
alter table public.site_admins enable row level security;

create or replace function public.is_site_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.site_admins where user_id = auth.uid())
$$;

-- Protege contra robôs: no máximo 30 mensagens por minuto, sempre chegam como "novo".
create or replace function public.site_inbox_guard()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.site_inbox where created_at > now() - interval '1 minute') >= 30 then
    raise exception 'Muitos envios em sequência. Tente de novo em um minuto.';
  end if;
  new.status := 'novo';
  new.created_at := now();
  return new;
end $$;
drop trigger if exists site_inbox_guard on public.site_inbox;
create trigger site_inbox_guard before insert on public.site_inbox for each row execute function public.site_inbox_guard();

drop policy if exists "visitantes enviam" on public.site_inbox;
drop policy if exists "dono le" on public.site_inbox;
drop policy if exists "dono muda" on public.site_inbox;
drop policy if exists "dono apaga" on public.site_inbox;
drop policy if exists "dono se ve" on public.site_admins;
create policy "visitantes enviam" on public.site_inbox for insert to anon, authenticated with check (true);
create policy "dono le" on public.site_inbox for select to authenticated using (public.is_site_admin());
create policy "dono muda" on public.site_inbox for update to authenticated using (public.is_site_admin()) with check (public.is_site_admin());
create policy "dono apaga" on public.site_inbox for delete to authenticated using (public.is_site_admin());
create policy "dono se ve" on public.site_admins for select to authenticated using (user_id = auth.uid());

revoke all on public.site_inbox from anon, authenticated;
revoke all on public.site_admins from anon, authenticated;
grant usage on schema public to anon, authenticated;
grant insert on public.site_inbox to anon, authenticated;
grant select, update, delete on public.site_inbox to authenticated;
grant select on public.site_admins to authenticated;
revoke all on function public.is_site_admin() from public, anon;
grant execute on function public.is_site_admin() to authenticated;

-- Quem administra o site. Cada e-mail precisa ter sido criado antes em Authentication > Users.
-- Para tirar o acesso de alguém, apague o usuário em Authentication > Users.
insert into public.site_admins (user_id)
select id from auth.users where lower(email) in ('marianoarthurdesde2010@gmail.com', 'zotdigitalctt@gmail.com')
on conflict (user_id) do nothing;

select e.email, case when exists (select 1 from public.site_admins a join auth.users u on u.id = a.user_id where lower(u.email) = e.email)
  then 'Pronto: já pode entrar no painel'
  else 'Falta criar este usuário em Authentication > Users e rodar o script de novo' end as situacao
from (values ('marianoarthurdesde2010@gmail.com'), ('zotdigitalctt@gmail.com')) as e(email);
